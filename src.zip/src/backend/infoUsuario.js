// src/backend/InfoUsuario.js
import express from "express";
import { conectar } from "./BaseDeDatos.js";

export function setInfoUsuario(app) {
  // Ya no necesita express.json() para GET
  app.get("/api/infoUsuario", (req, res) => {
    const { tipoUsuario, id } = req.query;
    if (!tipoUsuario || !id) {
      return res.status(400).json({ message: "Faltan parámetros" });
    }

    const connection = conectar();
    const tipo = parseInt(tipoUsuario, 10);

    if (tipo === 1) {
      const escuelaQuery = `
        SELECT u.id, u.nombre, u.email AS correo, e.foto AS imagen,
               e.descripcion, CONCAT(e.calle, ', ', e.colonia, ', CP ', e.cp) AS ubicacion
          FROM usuario u
          JOIN escuela e ON u.id = e.id_Usuario
         WHERE u.id = ?`;
      connection.query(escuelaQuery, [id], (err, results) => {
        if (err || results.length === 0) {
          connection.end();
          return res.status(404).json({ message: "Escuela no encontrada" });
        }
        const perfil = results[0];
        perfil.tipo = "escuela";

        const necesidadesQuery = `
          SELECT pn.id, ta.nombre AS tipoApoyo, pn.descripcion, pn.estado
            FROM perfilnecesidad pn
            JOIN tipoapoyo ta ON pn.id_Apoyo = ta.id
           WHERE pn.id_Escuela = ?`;
        connection.query(necesidadesQuery, [id], (err2, necesidades) => {
          connection.end();
          if (err2)
            return res
              .status(500)
              .json({ message: "Error al obtener necesidades" });

          perfil.necesidades = necesidades.map((n) => n.tipoApoyo);
          perfil.solicitudes = necesidades;
          res.json(perfil);
        });
      });
    } else if (tipo === 2) {
      const aliadoQuery = `
        SELECT u.id, u.nombre, u.email AS correo, a.foto AS imagen,
               a.descripcion, CONCAT(a.calle, ', ', a.colonia, ', CP ', a.cp) AS ubicacion
          FROM usuario u
          JOIN aliado a ON u.id = a.id_Usuario
         WHERE u.id = ?`;
      connection.query(aliadoQuery, [id], (err, results) => {
        if (err || results.length === 0) {
          connection.end();
          return res.status(404).json({ message: "Aliado no encontrado" });
        }
        const perfil = results[0];
        perfil.tipo = "aliado";

        const ofertasQuery = `
          SELECT po.id, ta.nombre AS tipoApoyo, po.descripcion, po.estado
            FROM perfiloferta po
            JOIN tipoapoyo ta ON po.id_Apoyo = ta.id
           WHERE po.id_Aliado = ?`;
        connection.query(ofertasQuery, [id], (err2, ofertas) => {
          connection.end();
          if (err2)
            return res
              .status(500)
              .json({ message: "Error al obtener ofertas" });

          perfil.ofertas = ofertas;
          res.json(perfil);
        });
      });
    } else {
      connection.end();
      res.status(400).json({ message: "tipoUsuario inválido" });
    }
  });
}
