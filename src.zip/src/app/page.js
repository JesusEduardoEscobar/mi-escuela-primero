import Inicio from "../components/inicioSesion"
export default function Home() {
  return (
      <Inicio className="bg-gradient-to-b from-green-500 to-white"/>
  );
}
