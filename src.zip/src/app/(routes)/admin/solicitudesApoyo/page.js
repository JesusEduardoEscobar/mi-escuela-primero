import SolicitudesApoyoPage from "@/components/solicitudes-apoyo";

export default function solicitudesAyudaApoyo() {
    return(
        <SolicitudesApoyoPage />
    )
}