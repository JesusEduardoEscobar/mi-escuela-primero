import SolicitudesAyudaPage from "@/components/solicituddes-ayuda";

export default function solicitudesAyuda() {
    return (
        <SolicitudesAyudaPage />
    )
}